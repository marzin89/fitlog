Testdata.doc innehåller de träningspass som jag har använt. 
Anpassa datumen så att varje träningspass hamnar inom det intervall som rubriken anger.
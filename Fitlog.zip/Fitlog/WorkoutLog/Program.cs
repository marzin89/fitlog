﻿/* Importerar namnrymder för listor, filhantering, serialisering och
    konsolen. */
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using static System.Console;

namespace WorkoutLog
{
    // Klassen hanterar information om övningar
    public class Exercise
    {
        // Fält
        // Övningens namn
        protected string? exerciseName;

        // Träningspasset som övningen ingår i
        protected string? workoutName;

        // Datum för träningspasset som övningen ingår i
        protected DateTime workoutDate;

        // Filnamn
        protected string fileName = "Muscles.json";

        // Total vikt för övningen
        protected double totalWeight;

        // Totalt antal set för övningen
        protected int totalSets;

        // Totalt antal reps
        protected int totalReps;

        // Properties med getters och setters för ovanstående fält
        public string? ExerciseName {get; set;}

        public string? WorkoutName {get; set;}

        public DateTime WorkoutDate {get; set;}

        public double TotalWeight {get; set;}
        public int TotalSets {get; set;}
        public int TotalReps {get; set;}     
    }

    // Klassen lagrar de muskler/muskelgrupper som användaren anger
    public class Muscles
    {  
        // Fält
        // Muskelns namn
        protected string? muscle;

        // Namnet på träningspasset som muskeln ingick i
        protected string? workoutName;

        // Datum för träningspasset som muskeln ingick i
        protected DateTime workoutDate;

        // Namnet på övningen som muskeln ingick i
        protected string? exerciseName;

        // Filnamn
        protected string fileName = "Muscles.json";

        // Properties med getters och setters för fälten
        public string? Muscle {get; set;}
        public string? WorkoutName {get; set;}
        public DateTime WorkoutDate {get; set;}
        public string? ExerciseName {get; set;}

        // Metoder
        /* Serialiserar listan på muskler som skapas/uppdateras när användaren 
            lägger til ett träningspass. */
        public void AddMuscle(List<Muscles> muscleList)
        {
            // Serialiserar med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(muscleList, options);
            File.WriteAllText(fileName, jsonString);
        }

        // Raderar muskler när användaren raderar ett träningspass
        public void DeleteMuscles(List<Muscles> muscleList, Workout deletedWorkout)
        {
            // I denna lista lagras de muskler som inte ska tas bort
            List<Muscles> updatedMuscleList = new List<Muscles>();

            /* Loopar igenom listan (argument 1) och jämför träningspassets namn
                och datum med det borttagna träningspasset (argument 2). */
            foreach(Muscles muscle in muscleList)
            {   /* Om dessa uppgifter inte stämmer överens, ska muskeln inte tas bort
                    och läggs till i listan ovan. */
                if (muscle.WorkoutName != deletedWorkout.WorkoutName |
                    muscle.WorkoutDate != deletedWorkout.WorkoutDate)
                {
                    updatedMuscleList.Add(muscle);
                }
            }

            // Serialiserar den uppdaterade listan med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(updatedMuscleList, options);
            File.WriteAllText(fileName, jsonString);
        }
    }

    // Klass som hanterar vikt och reps för ett set
    public class Set
    {   
        // Fält
        // Namnet på träningspasset som setet ingick i
        protected string? workoutName;

        // Datum för träningspasset som setet ingick i
        protected DateTime workoutDate;

        // Namnet på övningen som setet ingick i
        protected string? exerciseName;

        // Filnamn
        protected string fileName = "Sets.json";
        // Setets ID
        public int setID;

        // Antal reps för setet
        public int reps;

        // Vikt för setet
        public double weight;

        // Properties med getters och setters för fälten
        public string? WorkoutName {get; set;}
        public DateTime WorkoutDate {get; set;}
        public string? ExerciseName {get; set;}
        public int SetID {get; set;}
        public int Reps {get; set;}
        public double Weight {get; set;}
        
        // Metoder
        // Lägger till ett set
        public void AddSet(List<Set> setList)
        {
            // Serialiserar med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(setList, options);
            File.WriteAllText(fileName, jsonString);
        }

        // Raderar set när användaren raderar ett träningspass
        public void DeleteSets(List<Set> setList, Workout deletedWorkout)
        {
            // I denna lista lagras de set som inte ska tas bort
            List<Set> updatedSetList = new List<Set>();

            /* Loopar igenom listan (argument 1) och jämför träningspassets namn
                och datum med det borttagna träningspasset (argument 2). */
            foreach(Set set in setList)
            {   /* Om dessa uppgifter inte stämmer överens, ska muskeln inte tas bort
                    och läggs till i listan ovan. */
                if (set.WorkoutName != deletedWorkout.WorkoutName |
                    set.WorkoutDate != deletedWorkout.WorkoutDate)
                {
                    updatedSetList.Add(set);
                }
            }

            // Serialiserar den uppdaterade listan med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(updatedSetList, options);
            File.WriteAllText(fileName, jsonString);
        }
    }

    /* Klass som lagrar övningar i en lista och hanterar statistik/framgång
        för övningar. */
    public class ExerciseList : Exercise
    {
        // Fält
        // Filnamn
        protected string? fileName = "Exercises.json";
        
        // Lagrar nya samt befintliga övningar
        public List<Exercise> exercises = new List<Exercise>();

        // Fälten nedan används för att ta fram statistik/framgång över tid
        // Vikt över tid
        protected double weightOverTime;

        // Set över tid
        protected int setsOverTime;

        // Reps över tid
        protected int repsOverTime;
        protected string weightProgress;
        protected string setsProgress;
        protected string repsProgress;

        // Properties med getters och setters för fälten
        public List<Exercise> Exercises {get;}
        public List<Exercise> exercisesOverTime = new List<Exercise>();
        public double WeightOverTime {get; set;}
        public int SetsOverTime {get; set;}
        public int RepsOverTime {get; set;}

        public string WeightProgress {get; set;}
        public string SetsProgress {get; set;}
        public string RepsProgress {get; set;}

        // Metoder
        // Konstruerare
        /* Om filen finns och har ett innehåll, läses innehålet in, deserialiseras
            och lagras i listan ovan. */
        public ExerciseList()
        {
            if (File.Exists(fileName))
            {
                if (new FileInfo(fileName).Length > 0)
                {
                    string jsonString = File.ReadAllText(fileName);
                    exercises = JsonSerializer.Deserialize<List<Exercise>>(jsonString);
                }
            }
        }

        // Lägger till en ny övning i listan
        public void AddExercise(Exercise exercise)
        {
            exercises.Add(exercise);
        }
        
        // Serialiserar listan på övningar med indrag och skriver till filen
        public void AddExercises()
        {
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(exercises, options);
            File.WriteAllText(fileName, jsonString);
        }

        // Raderar övningar när användaren raderar ett träningspass
        public void DeleteExercises(Workout deletedWorkout)
        {
            // Här lagras de övningar som inte ska raderas
            List<Exercise> updatedExerciseList = new List<Exercise>();

            /* Loopar igenom listan på övningar och jämför träningspassets namn
                och datum med det borttagna träningspasset. */
            foreach(Exercise exercise in exercises)
            {
                // Om dessa inte stämmer överens, lagras övningen i listan ovan
                if (exercise.WorkoutName != deletedWorkout.WorkoutName |
                    exercise.WorkoutDate != deletedWorkout.WorkoutDate)
                {
                    updatedExerciseList.Add(exercise);
                }
            }

            // Serialiserar den uppdaterade listan med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(updatedExerciseList, options);
            File.WriteAllText(fileName, jsonString);
        }

        /* Lägger till övningar i listan som används för att ta fram statistik/framgång
            över tid. */
        public void AddExercisesOverTime(Exercise exercise)
        {
            exercisesOverTime.Add(exercise);
        }

        // Här beräknas statistik och framgång för en övning över tid
        public void ExerciseProgress(string name, int range)
        {
            // Lagrar dagens datum
            DateTime today = DateTime.Now;

            // Här lagras "startdatumet"
            DateTime startDate;

            /* Här beräknas startdatumet baserat på dagens datum och användarens val.
                Har användaren valt senaste veckan, blir startdatumet dagens datum minus
                sju dagar. Har användaren valt senaste månaden, så blir startdatumet
                dagens datum minus 30 dagar o.s.v. */
            switch(range)
            {
                // Senaste veckan
                case 1:
                {
                    startDate = today.AddDays(- 7);
                break;
                }
                // Senaste månaden
                case 2:
                {
                    startDate = today.AddDays(- 30);
                break;
                }
                // Senaste tre månaderna
                case 3:
                {
                    startDate = today.AddDays(- 90);
                break;
                }
                // Senaste halvåret
                case 4:
                {
                    startDate = today.AddDays(- 180);
                break;
                }
                // Senaste året
                default:
                {
                    startDate = today.AddDays(- 365);
                break;
                }
            }

            // Loopar igenom listan på övningar
            foreach(Exercise exercise in exercises)
            {
                // Kontrollerar om övningens namn stämmer överens med användarens val
                if (exercise.ExerciseName == name)
                {
                    // Kontrollerar om övningens datum ligger inom tidsintervallet
                    if (exercise.WorkoutDate >= startDate & exercise.WorkoutDate <= today)
                    {
                        // Lägger till total vikt, totalt antal set och reps i respektive property
                        WeightOverTime += exercise.TotalWeight;
                        SetsOverTime += exercise.TotalSets;
                        RepsOverTime += exercise.TotalReps;

                        // Lägger till övningen i listan
                        AddExercisesOverTime(exercise);
                    }
                }
            }

            // Kontrollerar om vi ens hittade någon övning
            if (exercisesOverTime.Count > 0)
            {
                // Lagrar listans sista index
                int lastIndex = exercisesOverTime.Count - 1;

                /* Här beräknas framgången i procent. Den första och den sista övningen i
                    listan används. */
                // Här beräknas framgången för vikt
                /* Om användaren lyfte med vikt i den första övningen jämfört med den sista
                    övningen. */
                if (exercisesOverTime[0].TotalWeight > 
                    exercisesOverTime[lastIndex].TotalWeight)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i WeightProgress. */
                    double difference = exercisesOverTime[0].TotalWeight - 
                    exercisesOverTime[lastIndex].TotalWeight;
                    double progress = difference / exercisesOverTime[0].TotalWeight;
                    WeightProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren lyfte mindre vikt i den första övningen jämfört med den sista
                    övningen. */
                else if (exercisesOverTime[0].TotalWeight <
                    exercisesOverTime[lastIndex].TotalWeight)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i WeightProgress. */
                    double difference = exercisesOverTime[lastIndex].TotalWeight
                    - exercisesOverTime[0].TotalWeight;
                    double progress = difference / exercisesOverTime[0].TotalWeight;
                    WeightProgress = "+ " + Convert.ToString(progress * 100) + " %";
                }
                // Om användaren lyfte lika mycket
                else
                {
                    // Behöver jag förklara detta?
                    WeightProgress = "0 %";
                }

                // Här beräknas framgången för antal set
                /* Om användaren gjorde fler set av den första övningen jämfört med den sista
                    övningen. */
                if (exercisesOverTime[0].TotalSets > 
                    exercisesOverTime[lastIndex].TotalSets)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i SetsProgress. */
                    double difference = exercisesOverTime[0].TotalSets -
                    exercisesOverTime[lastIndex].TotalSets;
                    double progress = difference / exercisesOverTime[0].TotalSets;
                    SetsProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren gjorde färre set av den första övningen jämfört med den sista
                    övningen. */
                else if (exercisesOverTime[0].TotalSets <
                    exercisesOverTime[lastIndex].TotalSets)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i SetsProgress. */
                    double difference = exercisesOverTime[lastIndex].TotalSets
                    - exercisesOverTime[0].TotalSets;
                    double progress = difference /
                    exercisesOverTime[lastIndex].TotalSets;
                    SetsProgress = "+ " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                // Om användaren gjorde lika många set
                else
                {
                    // Behöver jag förklara detta?
                    SetsProgress = "0 %";
                }

                // Här beräknas framgången för antal reps
                /* Om användaren gjorde fler reps av den första övningen jämfört med den sista
                    övningen. */
                if (exercisesOverTime[0].TotalReps > 
                    exercisesOverTime[lastIndex].TotalReps)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i RepsProgress. */
                    double difference = exercisesOverTime[0].TotalReps -
                    exercisesOverTime[lastIndex].TotalReps;
                    double progress = difference / exercisesOverTime[0].TotalReps;
                    RepsProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren gjorde färre reps av den första övningen jämfört med den sista
                    övningen. */
                else if (exercisesOverTime[0].TotalReps <
                    exercisesOverTime[lastIndex].TotalReps)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i RepsProgress. */
                    double difference = exercisesOverTime[lastIndex].TotalReps
                    - exercisesOverTime[0].TotalReps;
                    double progress = difference / exercisesOverTime[0].TotalReps;
                    RepsProgress = "+ " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                // Om användaren gjorde lika många reps
                else
                {
                    // Behöver jag förklara detta?
                    RepsProgress = "0 %";
                }
                
                // Skriver ut statistik och framgång för total vikt, antal set och reps
                WriteLine($"\nTotal vikt: {WeightOverTime}");
                WriteLine($"Framgång: {WeightProgress}");
                WriteLine($"\nTotalt antal set: {SetsOverTime}");
                WriteLine($"Framgång: {SetsProgress}");
                WriteLine($"\nTotalt antal reps: {RepsOverTime}");
                WriteLine($"Framgång: {RepsProgress}\n");
            }
            /* Skriver ut ett felmeddelande och avslutar programmet om ingen övning
                kunde hittas. */
            else
            {
                WriteLine("Kunde inte hitta några övningar för det valda intervallet");
                Environment.Exit(0);
            }
        }           
    }

    // Klassen hanterar information om träningspass
    public class Workout
    {
        // Fält
        // Träningspassets namn
        protected string? workoutName;

        // Datum för träningspasset
        protected DateTime workoutDate;

        // Antal tränade muskler
        protected int totalMusclesWorked;

        // Antal övningar  
        protected int totalExercises;

        // Total vikt
        protected double totalWeightPerWorkout;

        // Totalt antal set
        protected int totalSetsPerWorkout;

        // Totalt antal reps
        protected int totalRepsPerWorkout;

        // Properties med getters och setters för fälten
        public string? WorkoutName {get; set;}
        public DateTime WorkoutDate {get; set;}
        public int TotalExercises {get; set;} 
        public int TotalMusclesWorked {get; set;} 
        public double TotalWeightPerWorkout {get; set;}
        public int TotalSetsPerWorkout {get; set;} 
        public int TotalRepsPerWorkout {get; set;}
    }

    // Klassen hämtar, lägger till, uppdaterar och raderar träningspass
    public class Log : Workout
    {
        // Fält
        // Filnamn
        protected string fileName = "Workouts.json";

        // Lagrar nya och befintliga träningspass
        public List<Workout>? workouts = new List<Workout>();

        // Fälten används för att ta fram statistik/framgång över tid
        // Vikt över tid
        protected double weightOverTime;

        // Set över tid
        protected int setsOverTime;

        // Reps över tid
        protected int repsOverTime;

        // Framgång för vikt
        protected string weightProgress;

        // Framgång för set
        protected string setsProgress;

        // Framgång för reps
        protected string repsProgress;

        // Lagrar träningspass som finns i tidsintervallet som användaren har valt
        protected List<Workout>? workoutsOverTime = new List<Workout>();

        // Properties med getters och setters för fälten
        public List<Workout>? Workouts {get;}
        public List<Workout> WorkoutsOverTime {get;}
        public double WeightOverTime {get; set;}
        public int SetsOverTime {get; set;}
        public int RepsOverTime {get; set;}

        public string WeightProgress {get; set;}
        public string SetsProgress {get; set;}
        public string RepsProgress {get; set;}

        // Metoder
        // Konstruerare
        public Log()
        {
            // Kontrollerar om filen finns
            if (File.Exists(fileName))
            {
                // Kontrollerar om filen har ett innehåll
                if (new FileInfo(fileName).Length > 0)
                {
                    /* Läser in befintliga träningspass, deserialiserar och lägger 
                    till i listan */
                    string jsonString = File.ReadAllText(fileName);
                    workouts = JsonSerializer.Deserialize<List<Workout>>(jsonString);
                }
            }
        }

        // Lägger till träningspass i listan för statistik/framgång
        public void AddWorkoutsOverTime(Workout workout)
        {
            workoutsOverTime.Add(workout);
        }

        // Lägger till träningspass i listan
        public void AddWorkout(object workout)
        {
            workouts.Add((Workout)workout);

            // Serialiserar listan med indrag och skriver till filen
            var options = new JsonSerializerOptions{WriteIndented = true};
            string jsonString = JsonSerializer.Serialize(workouts, options);
            File.WriteAllText(fileName, jsonString);

            // Bekräftar lagringen
            WriteLine("\nTräningspasset har sparats");
        }

        // Tar fram statistik/framgång över tid för ett träningspass
        public void WorkoutProgress(string name, int range)
        {
            // Lagrar dagens datum
            DateTime today = DateTime.Now;

            // Här lagras "startdatumet"
            DateTime startDate;

            /* Här beräknas startdatumet baserat på dagens datum och användarens val.
                Har användaren valt senaste veckan, blir startdatumet dagens datum minus
                sju dagar. Har användaren valt senaste månaden, så blir startdatumet
                dagens datum minus 30 dagar o.s.v. */
            switch(range)
            {
                // Senaste veckan
                case 1:
                {
                    startDate = today.AddDays(- 7);
                break;
                }
                // Senaste månaden
                case 2:
                {
                    startDate = today.AddDays(- 30);
                break;
                }
                // Senaste tre månaderna
                case 3:
                {
                    startDate = today.AddDays(- 90);
                break;
                // Senaste halvåret
                }
                case 4:
                {
                    startDate = today.AddDays(- 180);
                break;
                }
                // Senaste året
                default:
                {
                    startDate = today.AddDays(- 365);
                break;
                }
            }

            // Loopar igenom listan på övningar
            foreach(Workout workout in workouts)
            {
                // Kontrollerar om träningspassets namn stämmer överens med användarens val
                if (workout.WorkoutName == name)
                {
                    // Kontrollerar om träningspassets datum ligger inom tidsintervallet
                    if (workout.WorkoutDate >= startDate & workout.WorkoutDate <= today)
                    {
                        // Lägger till total vikt, totalt antal set och reps i respektive property
                        WeightOverTime += workout.TotalWeightPerWorkout;
                        SetsOverTime += workout.TotalSetsPerWorkout;
                        RepsOverTime += workout.TotalRepsPerWorkout;

                        // Lägger till träningspasset i listan
                        AddWorkoutsOverTime(workout);
                    }
                }
            }

            // Kontrollerar om vi ens hittade något träningspass
            if (workoutsOverTime.Count > 0)
            {
                // Lagrar listans sista index
                int lastIndex = workoutsOverTime.Count - 1;

                /* Här beräknas framgången i procent. Det första och det sista träningspasset i
                    listan används. */
                // Här beräknas framgången för vikt
                /* Om användaren lyfte mer vikt i det första träningspasset jämfört med det sista
                    träningspasset. */
                if (workoutsOverTime[0].TotalWeightPerWorkout > 
                    workoutsOverTime[lastIndex].TotalWeightPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i WeightProgress. */
                    double difference = workoutsOverTime[0].TotalWeightPerWorkout - 
                    workoutsOverTime[lastIndex].TotalWeightPerWorkout;
                    double progress = difference / workoutsOverTime[0].TotalWeightPerWorkout;
                    WeightProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren lyfte mindre vikt i det första träningspasset jämfört med det sista
                    träningspasset. */
                else if (workoutsOverTime[0].TotalWeightPerWorkout <
                    workoutsOverTime[lastIndex].TotalWeightPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i WeightProgress. */
                    double difference = workoutsOverTime[lastIndex].TotalWeightPerWorkout
                    - workoutsOverTime[0].TotalWeightPerWorkout;
                    double progress = difference / workoutsOverTime[0].TotalWeightPerWorkout;
                    WeightProgress = "+ " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                // Om användaren lyfte lika mycket
                else
                {
                    // Behöver jag förklara detta?
                    WeightProgress = "0 %";
                }

                // Här beräknas framgången för antal set
                /* Om användaren gjorde fler set i det första träningspasset jämfört med det sista
                    träningspasset. */
                if (workoutsOverTime[0].TotalSetsPerWorkout > 
                    workoutsOverTime[lastIndex].TotalSetsPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i SetsProgress. */
                    double difference = workoutsOverTime[0].TotalSetsPerWorkout -
                    workoutsOverTime[lastIndex].TotalSetsPerWorkout;
                    double progress = difference / workoutsOverTime[0].TotalSetsPerWorkout;
                    SetsProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren gjorde färre set i det första träningspasset jämfört med det sista
                    träningspasset. */
                else if (workoutsOverTime[0].TotalSetsPerWorkout <
                    workoutsOverTime[lastIndex].TotalSetsPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i WeightProgress. */
                    double difference = workoutsOverTime[lastIndex].TotalSetsPerWorkout
                    - workoutsOverTime[0].TotalSetsPerWorkout;
                    double progress = difference /
                    workoutsOverTime[lastIndex].TotalSetsPerWorkout;
                    SetsProgress = "+ " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                // Om användaren gjorde lika många set
                else
                {
                    // Behöver jag förklara detta?
                    SetsProgress = "0 %";
                }

                // Här beräknas framgången för antal reps
                /* Om användaren gjorde fler reps i det första träningspasset jämfört med det sista
                    träningspasset. */
                if (workoutsOverTime[0].TotalRepsPerWorkout > 
                    workoutsOverTime[lastIndex].TotalRepsPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i SetsProgress. */
                    double difference = workoutsOverTime[0].TotalRepsPerWorkout -
                    workoutsOverTime[lastIndex].TotalRepsPerWorkout;
                    double progress = difference / workoutsOverTime[0].TotalRepsPerWorkout;
                    RepsProgress = "- " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                /* Om användaren gjorde färre reps i det första träningspasset jämfört med det sista
                    träningspasset. */
                else if (workoutsOverTime[0].TotalRepsPerWorkout <
                    workoutsOverTime[lastIndex].TotalRepsPerWorkout)
                {
                    /* Beräknar differensen och framgången avrundat till heltal och lagrar
                        som en sträng i SetsProgress. */
                    double difference = workoutsOverTime[lastIndex].TotalRepsPerWorkout
                    - workoutsOverTime[0].TotalRepsPerWorkout;
                    double progress = difference / workoutsOverTime[0].TotalRepsPerWorkout;
                    RepsProgress = "+ " + Convert.ToString(Math.Round(progress * 100)) + " %";
                }
                // Om användaren gjorde lika många reps
                else
                {
                    // Behöver jag förklara detta?
                    RepsProgress = "0 %";
                }
                
                // Skriver ut statistik och framgång för total vikt, antal set och reps
                WriteLine($"\nTotal vikt: {WeightOverTime}");
                WriteLine($"Framgång: {WeightProgress}");
                WriteLine($"\nTotalt antal set: {SetsOverTime}");
                WriteLine($"Framgång: {SetsProgress}");
                WriteLine($"\nTotalt antal reps: {RepsOverTime}");
                WriteLine($"Framgång: {RepsProgress}\n");
            }
            /* Skriver ut ett felmeddelande och avslutar programmet om inget träningspass
                kunde hittas. */
            else
            {
                WriteLine("Kunde inte hitta några träningspass för det valda intervallet");
                Environment.Exit(0);
            }
        }

        // Raderar ett träningspass ur listan
        public Workout DeleteWorkout(int index)
        {
            /* Kontrollerar att index är större än eller lika med noll 
                och mindre än listan på träningspass */
            if (index >= 0 & index < workouts.Count)
            {
                // Lagrar träningspasset som ska raderas
                var workout = workouts[index];

                // Tar bort träningspasset ur listan
                workouts.RemoveAt(index);

                // Serialiserar listan med indrag och skriver till filen
                var options = new JsonSerializerOptions{WriteIndented = true};
                string jsonString = JsonSerializer.Serialize(workouts, options);
                File.WriteAllText(fileName, jsonString);

                // Bekräftar borttagningen
                WriteLine("\nTräningpasset har raderats");

                // Returnerar träningspasset
                return workout;
            }
            /* Om index är för stort eller för litet, skrivs ett 
                felmeddelande ut, programmet avslutas och en tom
                instans returneras */
            else
            {
                var workout = new Workout();
                WriteLine("Det valda träningspasset finns inte");
                Environment.Exit(0);
                return workout;
            }           
        }
    }
    public class program
    {
        public static void Main(string[] args)
        {
            // Ny instans av träningsdagboken
            var log = new Log();

            // Säkerställer att programmet startas om efter varje genomfört val (ej X)
            bool run = true;

            // Programmet körs så länge variabeln ovan är true
            while(run == true)
            {
                // Kontrollerar om det finns träningspass
                if (log.workouts.Count > 0)
                {
                    // Meny om det finns träningspass
                    WriteLine("F I T L O G");
                    WriteLine("Välkommen tillbaka! Vad vill du göra i dag?\n");
                    WriteLine("\n1. Lägg till ett träningspass");
                    WriteLine("2. Ta bort ett träningspass");
                    WriteLine("3. Visa min framgång");
                    WriteLine("X Avsluta\n");

                    // Här skrivs det senaste träningspasset ut
                    // Nya instanser av ExerciseList, Muscles och Set
                    var exerciseList = new ExerciseList();
                    var muscles = new Muscles();

                    // I listan lagras befintliga muskler
                    List<Muscles> newMuscleList = new List<Muscles>();

                    // Läser in innehållet i filen
                    string jsonString = File.ReadAllText("Muscles.json");

                    // Deserialiserar och lagrar i listan
                    newMuscleList = JsonSerializer.Deserialize<List<Muscles>>(jsonString);

                    // Lagrar det sista träningspasset i listan
                    int lastIndex = log.workouts.Count - 1;

                    // Utskrift
                    // Namn och datum
                    WriteLine("\nDitt senaste träningspass");
                    WriteLine($"Namn: {log.workouts[lastIndex].WorkoutName}");
                    WriteLine($"Datum: {log.workouts[lastIndex].WorkoutDate}");

                    // Övningar som ingick
                    WriteLine("\nÖvningar:");

                    /* Loopar igenom listan på övningar och jämför varje övning med det 
                        sista träningspasset */
                    foreach(Exercise exercise in exerciseList.exercises)
                    {
                        // Om träningspassets namn och datum stämmer överens, skrivs övningen ut
                        if (exercise.WorkoutName == log.workouts[lastIndex].WorkoutName &
                            exercise.WorkoutDate == log.workouts[lastIndex].WorkoutDate)
                        {
                            WriteLine(exercise.ExerciseName);
                        }
                    }

                    // Tränade muskler
                    WriteLine("\nTränade muskler:");

                    /* Loopar igenom listan på muskler och jämför varje muskel med det 
                        sista träningspasset */
                    foreach(Muscles muscle in newMuscleList)
                    {
                        // Om träningspassets namn och datum stämmer överens, skrivs muskeln ut
                        if (muscle.WorkoutName == log.workouts[lastIndex].WorkoutName &
                            muscle.WorkoutDate == log.workouts[lastIndex].WorkoutDate)
                        {
                            WriteLine(muscle.Muscle);
                        }
                    }

                    // Total vikt, totalt antal set och reps för träningspasset
                    WriteLine($"\nTotal vikt: {log.workouts[lastIndex].TotalWeightPerWorkout}");
                    WriteLine($"Totalt antal set: {log.workouts[lastIndex].TotalSetsPerWorkout}");
                    WriteLine($"Totalt antal reps: {log.workouts[lastIndex].TotalRepsPerWorkout}");   
                }
                else
                {
                    // Meny om träningsdagboken är tom
                    WriteLine("F I T L O G");
                    WriteLine("Välkommen tillbaka! Vad vill du göra i dag?");
                    WriteLine("\n1. Lägg till ett träningspass");
                    WriteLine("X Avsluta\n");
                    WriteLine("Träningsdagboken är tom");
                }

                // Läser in användarens val
                string userChoice;

                // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                while (string.IsNullOrEmpty(userChoice = ReadLine()))
                {
                    WriteLine("Välj ett alternativ i menyn");
                }

                // Switch-sats baserat på användarens val
                switch(userChoice)
                {
                    // Lägg till ett träningspass
                    case "1":
                    {
                        // Nya instanser av övning och träningspass
                        var workout = new Workout();
                        var exerciseList = new ExerciseList();

                        // Ber användaren ange träningspassets namn och läser in det
                        WriteLine("\nAnge träningspassets namn");
                        string workoutName;

                        // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                        while(string.IsNullOrEmpty(workoutName = ReadLine()))
                        {
                            WriteLine("Du måste ange träningspassets namn");
                        }

                        // Lagrar namnet i Workout
                        workout.WorkoutName = workoutName;

                        // Ber användaren ange träningspassets datum och läser in det
                        WriteLine("\nAnge träningspassets datum (åååå-mm-dd)");
                        string workoutDate;

                        // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                        while(string.IsNullOrEmpty(workoutDate = ReadLine()))
                        {
                            WriteLine("Du måste ange träningspassets datum");
                        }

                        DateTime date;

                        // Kontrollerar om ett giltigt datum har angetts
                        if(DateTime.TryParse(workoutDate, out date))
                        {
                            // Lagrar datumet i Workout
                            workout.WorkoutDate = date;
                        }
                        /* Skriver ut ett felmeddelande och avslutar programmet om användaren
                            har angett ett ogiltigt datum. */
                        else
                        {
                            WriteLine("Ogiltigt datum. Datum måste anges i formatet åååå-mm-dd.");
                            Environment.Exit(0);
                        }

                        // Så länge denna variabel är true, upprepas loopen nedan
                        bool addExercises = true;

                        // Här lägger vi till övningar
                        while(addExercises == true)
                        {
                            // Ny instans av Exercise
                            var exercise = new Exercise();

                            // Ber användaren ange en övning och läser in den
                            WriteLine("\nLägg till en övning");
                            string exerciseName;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(exerciseName = ReadLine()))
                            {
                                WriteLine("Du måste lägga till en övning");
                            }

                            /* Lagrar övningens och träningspassets namn och datum i klassens 
                                properties. */
                            exercise.ExerciseName = exerciseName;
                            exercise.WorkoutName = workout.WorkoutName;
                            exercise.WorkoutDate = workout.WorkoutDate;

                            // Ber användaren ange antal tränade muskler och läser in det
                            WriteLine("\nAnge antal tränade muskler");
                            string musclesWorked;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(musclesWorked = ReadLine()))
                            {
                                WriteLine("Du måste ange antal tränade muskler");
                            }

                            int numberOfMusclesWorked;

                            // Kontrollerar om användaren har angett ett heltal
                            if (int.TryParse(musclesWorked, out numberOfMusclesWorked))
                            {
                                // Ny instans av muscles
                                var muscleObj = new Muscles();

                                // Ny lista på muskler
                                List<Muscles> muscleList = new List<Muscles>();

                                // Kontrollerar om filen finns
                                if (File.Exists("Muscles.json"))
                                {
                                    // Kontrollerar om filen har något innehåll
                                    if (new FileInfo("Muscles.json").Length > 0)
                                    {
                                        // Läser in, deserialiserar och lagrar i listan
                                        string json = File.ReadAllText("Muscles.json");
                                        muscleList = JsonSerializer.Deserialize<List<Muscles>>(json);
                                    }
                                }

                                /* Här lägger användaren till tränade muskler baserat på det
                                    antal som angetts. */
                                for(int i = 0; i < numberOfMusclesWorked; i++)
                                {
                                    // Ny instans av Muscles
                                    var newMuscle = new Muscles();

                                    // Ber användaren ange en muskel och läser in
                                    WriteLine($"\nMuskel {i + 1}:");
                                    string muscle;

                                    // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                                    while(string.IsNullOrEmpty(muscle = ReadLine()))
                                    {
                                        WriteLine("Du måste ange en muskel");
                                    }

                                    /* Lagrar muskelns namn, träningspassets namn och datum samt övningens namn
                                        i klassens properties. */
                                    newMuscle.Muscle = muscle;
                                    newMuscle.WorkoutName = workout.WorkoutName;
                                    newMuscle.WorkoutDate = workout.WorkoutDate;
                                    newMuscle.ExerciseName = exercise.ExerciseName;

                                    // Lagrar muskeln i listan
                                    muscleList.Add(newMuscle);
                                }

                                // Serialiserar listan
                                muscleObj.AddMuscle(muscleList);
                            }
                            /* Skriver ut ett felmeddelande och avslutar programmet om användaren inte
                                har angett ett heltal. */
                            else
                            {
                                WriteLine("Antal tränade muskler måste anges i heltal");
                                Environment.Exit(0);
                            }

                            // Ber användaren ange antal set och läser in
                            WriteLine("\nAnge antal set");
                            string sets;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(sets = ReadLine()))
                            {
                                WriteLine("Du måste ange antal set");
                            }

                            int numberOfSets;

                            // Kontrollerar om användaren har angett ett heltal
                            if (int.TryParse(sets, out numberOfSets))
                            {
                                // Ny instans av set
                                var set = new Set();

                                // Ny lista på set
                                List<Set> setList = new List<Set>();

                                // Kontrollerar om filen finns
                                if (File.Exists("Sets.json"))
                                {
                                    // Kontrollerar om filen har något innehåll
                                    if (new FileInfo("Sets.json").Length > 0)
                                    {
                                        // Läser in, deserialiserar och lagrar i listan
                                        string json = File.ReadAllText("Sets.json");
                                        setList = JsonSerializer.Deserialize<List<Set>>(json);
                                    }
                                }

                                /* Här lägger användaren till set baserat på det
                                    antal som angetts. */
                                for(int i = 0; i < numberOfSets; i++)
                                {
                                    // Ny instans av Set
                                    var newSet = new Set();

                                    // Ber användaren ange vikt och läser in
                                    WriteLine($"\nVikt för set {i + 1} (kg):");
                                    string setWeight;

                                    // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                                    while(string.IsNullOrEmpty(setWeight = ReadLine()))
                                    {
                                        WriteLine("Du måste ange en vikt");
                                    }

                                    double weight;
                                    
                                    /* Lagrar vikten i klassens property om användaren har angett ett 
                                        heltal eller ett decimaltal. */
                                    if (double.TryParse(setWeight, out weight))
                                    {
                                        newSet.Weight = weight;
                                    }
                                    else
                                    {
                                        /* Skriver ut ett felmeddelande och avslutar programmet om 
                                            användaren inte har angett ett heltal eller ett decimaltal. */
                                        WriteLine("Vikt måste anges i heltal eller decimaltal");
                                        Environment.Exit(0);
                                    }

                                    // Ber användaren ange antal reps och läser in
                                    WriteLine($"\nReps för set {i + 1}:");
                                    string setReps;

                                    // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                                    while(string.IsNullOrEmpty(setReps = ReadLine()))
                                    {
                                        WriteLine("Du måste ange antal reps");
                                    }

                                    int reps;

                                    // Lagrar vikten i klassens property om användaren har angett ett heltal.
                                    if (int.TryParse(setReps, out reps))
                                    {
                                        newSet.Reps = reps;
                                    }
                                    /* Skriver ut ett felmeddelande och avslutar programmet om användaren inte 
                                        har angett ett heltal. */
                                    else
                                    {
                                        WriteLine("Reps måste anges i heltal");
                                        Environment.Exit(0);
                                    }

                                    // Lagrar ID för setet samt total vikt, antal set och reps för övningen
                                    newSet.SetID = i + 1;
                                    /* Lagrar träningspassets namn och datum samt övningens namn
                                        i klassens properties. */
                                    newSet.WorkoutName = workout.WorkoutName;
                                    newSet.WorkoutDate = workout.WorkoutDate;
                                    newSet.ExerciseName = exercise.ExerciseName;

                                    // Lägger til setet i listan ovan
                                    setList.Add(newSet);
                                }

                                // Lagrar totalt antal set, total vikt och totalt antal reps för övningen
                                exercise.TotalSets = setList.Count;

                                foreach(Set element in setList)
                                {
                                    if (element.WorkoutName == exercise.WorkoutName &
                                        element.WorkoutDate == exercise.WorkoutDate &
                                        element.ExerciseName == exercise.ExerciseName)
                                    {
                                        exercise.TotalWeight += (element.Weight * element.Reps);
                                        exercise.TotalReps += element.Reps;
                                    }
                                }

                                // Serialiserar listan
                                set.AddSet(setList);
                            }
                            else
                            {
                                /* Skriver ut ett felmeddelande och avslutar programmet om användaren
                                    inte har angett ett heltal. */
                                WriteLine("Antal set måste anges i heltal");
                                Environment.Exit(0);
                            }

                            // Lagrar antal set för övningen
                            exercise.TotalSets = numberOfSets;

                            // Lägger till övningen i ExerciseList-klassens lista på övningar
                            exerciseList.AddExercise(exercise);
                           
                           /* Lagrar antal övningar, muskler, total vikt, totalt antal set och
                                reps i Workout. */
                            foreach(Exercise item in exerciseList.exercises)
                            {
                                if (item.WorkoutName == workout.WorkoutName &
                                    item.WorkoutDate == workout.WorkoutDate & 
                                    item.ExerciseName == exercise.ExerciseName)
                                {
                                    workout.TotalExercises += 1;
                                }
                            }

                            workout.TotalMusclesWorked += numberOfMusclesWorked;
                            workout.TotalWeightPerWorkout += exercise.TotalWeight;
                            workout.TotalSetsPerWorkout += exercise.TotalSets;
                            workout.TotalRepsPerWorkout += exercise.TotalReps;

                            /* Här väljer användaren att lägga till fler övningar eller
                                att spara träningspasset */
                            WriteLine("\n[1] Lägg till en till övning");
                            WriteLine("[2] Lägg till träningsprogrammet");

                            // Läser in användarens val
                            string addExerciseOrWorkout;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while (string.IsNullOrEmpty(addExerciseOrWorkout = ReadLine()))
                            {
                                WriteLine("Välj ett alternativ i menyn");
                            }

                            /* Om användaren har valt att lägga till fler övningar,
                                körs loopen igen */
                            if(addExerciseOrWorkout == "1")
                            {
                                addExercises = true;
                            }
                            // Om användaren har valt att spara träningspasset
                            else
                            {
                                // Serialiserar övningarna
                                exerciseList.AddExercises();

                                // Serialiserar träningspasset
                                log.AddWorkout(workout);

                                // Återgår till menyn
                                addExercises = false;
                            }         
                        }
                    break;
                    }
                    // Tar bort ett träningspass
                    case "2":
                    {
                        // Nya instanser av Workout, ExerciseList och Muscles
                        var workouts = new Workout();
                        var exercises = new ExerciseList();
                        var muscles = new Muscles();
                        var sets = new Set();

                        // I listan lagras befintliga muskler
                        List<Muscles> muscleList = new List<Muscles>();

                        // I listan lagras befintliga set
                        List<Set> setList = new List<Set>();

                        // Läser in befintliga muskler, deserialiserar och lagrar i listan
                        string jsonString = File.ReadAllText("Muscles.json");
                        muscleList = JsonSerializer.Deserialize<List<Muscles>>(jsonString);

                        // Läser in befintliga set, deserialiserar och lagrar i listan
                        string json = File.ReadAllText("Sets.json");
                        setList = JsonSerializer.Deserialize<List<Set>>(json);
                        
                        // Skriver ut befintliga träningspass med index, namn och datum
                        for(int count = 0; count < log.workouts.Count; count++)
                        {
                            WriteLine($"\n[{count + 1}] Namn: {log.workouts[count].WorkoutName}");
                            WriteLine($"Datum: {log.workouts[count].WorkoutDate}");
                        }

                        // Ber användaren välja ett träningspass och läser in valet
                        WriteLine("\nVälj ett träningspass ur listan (ange nummer)");
                        string workoutNumber;

                        // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                        while(string.IsNullOrEmpty(workoutNumber = ReadLine()))
                        {
                            WriteLine("Du måste välja ett träningspass");
                        }

                        int index;

                        // Kontrollerar om användaren har angett ett heltal
                        if (int.TryParse(workoutNumber, out index))
                        {
                            // Tar bort träningspasset, övningarna och musklerna som ingick
                            /* Det raderade träningspasset returneras och används som argument
                                i syfte att jämföra namn och datum för träningspasset. */
                            var deletedWorkout = log.DeleteWorkout(index - 1);
                            exercises.DeleteExercises(deletedWorkout);

                            /* Här används även listan på muskler som argument eftersom klassen
                                saknar en sådan. */
                            muscles.DeleteMuscles(muscleList, deletedWorkout);

                            /* Här används även listan på set som argument eftersom klassen
                                saknar en sådan. */
                            sets.DeleteSets(setList, deletedWorkout);
                        }
                        /* Skriver ut ett felmeddelande och avslutar programmet om användaren inte
                            har angett ett heltal. */
                        else
                        {
                            WriteLine("Du måste ange ett heltal");
                            Environment.Exit(0);
                        }
                    break;
                    }
                    // Statistik/framgång för träningspass/övningar
                    case "3":
                    {
                        /* Här väljer användaren om statistik/framgång ska visas för ett träningspass
                            eller en övning. */
                        WriteLine("\n1. Träningspass");
                        WriteLine("2. Övning");

                        // Läser in användarens val
                        string choice;

                        // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                        while (string.IsNullOrEmpty(choice = ReadLine()))
                        {
                            WriteLine("Välj ett alternativ i menyn");
                        }

                        // Om användaren har valt träningspass
                        if (choice == "1")
                        {
                            // Ny instans av Log
                            var newLog = new Log();

                            // Ber användaren ange träningspassets namn och läser in
                            WriteLine("\nAnge träningspassets namn");
                            string name;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(name = ReadLine()))
                            {
                                WriteLine("Du måste ange träningspassets namn");
                            }

                            /* Här väljer användaren inom vilket tidsintervall som statistik/framgång
                                ska visas. */
                            WriteLine("\nVälj ett intervall ur listan");
                            WriteLine("1. Senaste veckan");
                            WriteLine("2. Senaste månaden");
                            WriteLine("3. Senaste tre månaderna");
                            WriteLine("4. Senaste halvåret");
                            WriteLine("5. Senaste året");

                            // Läser in valet
                            string interval;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(interval = ReadLine()))
                            {
                                WriteLine("Du måste välja ett intervall");
                            }

                            int range;

                            // Kontrollerar om användaren har angett ett heltal
                            if (int.TryParse(interval, out range))
                            {
                                /* Tar fram statistik/framgång för det valda träningspasset
                                    och det valda tidsintervallet. */
                                newLog.WorkoutProgress(name, range);
                            }
                            /* Skriver ut ett felmeddelande och avslutar programmet om användaren inte
                                har angett ett heltal. */
                            else
                            {
                                WriteLine("Du måste ange ett heltal");
                                Environment.Exit(0);
                            }
                        }
                        // Om användaren har valt övning
                        else if (choice == "2")
                        {
                            // Ny instans av ExerciseList
                            var exerciseList = new ExerciseList();

                            // Ber användaren ange en övning och läser in
                            WriteLine("\nAnge övningens namn");
                            string name;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(name = ReadLine()))
                            {
                                WriteLine("Du måste ange övningens namn");
                            }

                            /* Här väljer användaren inom vilket tidsintervall som statistik/framgång
                                ska visas. */
                            WriteLine("\nVälj ett intervall ur listan");
                            WriteLine("1. Senaste veckan");
                            WriteLine("2. Senaste månaden");
                            WriteLine("3. Senaste tre månaderna");
                            WriteLine("4. Senaste halvåret");
                            WriteLine("5. Senaste året");

                            // Läser in valet
                            string interval;

                            // Skriver ut ett felmeddelande så länge användaren inte har skrivit något
                            while(string.IsNullOrEmpty(interval = ReadLine()))
                            {
                                WriteLine("Du måste välja ett intervall");
                            }

                            int range;

                            // Kontrollerar om användaren har angett ett heltal
                            if (int.TryParse(interval, out range))
                            {
                                /* Tar fram statistik/framgång för den valda övningen och det
                                    valda tidsintervallet. */
                                exerciseList.ExerciseProgress(name, range);
                            }
                            /* Skriver ut ett felmeddelande och avslutar programmet om användaren
                                inte har angett ett heltal. */
                            else
                            {
                                WriteLine("Du måste ange ett heltal");
                                Environment.Exit(0);
                            }
                        }
                    break;
                    }
                    // Avslutar programmet om användaren har valt det i huvudmenyn
                    case "X":
                    {
                        Environment.Exit(0);
                    break;
                    }
                }
            }
        }
    }
}
